import java.io.*;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
/**
 * Write a description of class Dictionary here.
 * 
 * @author (Chris Macleman, Adam Harmston, Peter Short, Abbas Lawal) 
 * @version (10/03/17)
 */
public class Dictionary
{
    private Word root;

    public String search2;
    public String fileRead;
    public String fileWrite;
    public String preorderEnglish = "";
    public String preorderGerman = "";

    /**
     * Constructor for objects of class Dictionary
     */
    public Dictionary(String english, String german)
    {
        root = new Word(english,german);
    }

    //Alternate constructor

    public Dictionary()
    {
        root = null;
    }

    public Word add(Word node, String english, String german)
    {

        return node;
    }

    public boolean add(String english, String german) 
    {

        Word newNode = new Word(english, german);
        Word current = root;
        Word previous = null;
        boolean foundNode = false;
        boolean valid;

        if(root == null)
        {
            root = newNode;

        }

        else
        {
            //find insertion point
            while(current != null)
            {
                if (current.getEnglish() == newNode.getEnglish())
                {
                    System.out.println("Value matches a previous one thats been entered, please try again");
                    return false;
                }
                else if ( current.getEnglish().compareTo(english) < 0) 
                {
                    previous = current;
                    current = current.getLeft();

                }
                else if (current.getEnglish().compareTo(english) > 0) 
                {
                    previous = current;
                    current = current.getRight();
                }
            }

            //now insert the number
            if(previous.getEnglish().compareTo(english) < 0)
            {
                previous.setLeft(newNode);
            }
            else
            {
                previous.setRight(newNode);
            }
        } 

        return true;
    }

    /**
     * prints all three trees, in order pre order and post order
     */

    public void printTree()
    {
        //      int id = 22;
        //      
        //
        //      System.out.println(" - In order english numbers - ");
        //      inOrder(root);
        //      System.out.println(" ");

        //      System.out.println(" - Pre order english numbers - ")  ;  
        //      preOrder(root);
        //      System.out.println(" ");

        //      System.out.println(" - Post order english numbers - ");
        //      postOrder(root);
        //      System.out.println(" ");

    }

    private void print(Word node)
    {

        if (node!=null)
        {

            print(node.getRight());

            System.out.println("English: " + node.getEnglish() + "\n"  + "German: " + node.getGerman() );
            print(node.getLeft());

        }
    }

    //prints the tree
    public void print()
    {
        print(root);
    }

    public void printTree2()
    {

        //System.out.println(" - In order student numbers - ");
        //inOrder(root);
        //System.out.println(" ");

        // System.out.println(" - Pre order student numbers - ")  ;  
        preOrder(root);
        //  System.out.println(" ");

        // System.out.println(" - Post order student numbers - ");
        // postOrder(root);
        //System.out.println(" ");

    }

    /**
     * in order print method, looks at the left side of the tree then prints then looks right
     */

    public void inOrder(Word node)
    {

        if(node != null)
        {

            inOrder(node.getLeft());

            System.out.println("englishs id is - " + node.getEnglish());
            System.out.println("german is - " + node.getGerman());
            System.out.println(" ");

            inOrder(node.getRight());
        }

    }

    public void preOrder(Word node)
    {
        if(node != null)
        {
            System.out.println("english meaning " + node.getEnglish());
            System.out.println(" German meaning- " + node.getGerman());
            System.out.println(" ");

            if(node.getLeft() != null)
                preOrder(node.getLeft());

            if(node.getRight() != null)
                preOrder(node.getRight());
        }
    }

    private void getPreOrder(Word node)
    {
        if (node == null)

            return;

        preorderEnglish = preorderEnglish + node.getEnglish() + "\n ";
        preorderGerman = preorderGerman + node.getGerman()  + "\n ";
        getPreOrder(node.getLeft());
        getPreOrder(node.getRight());
    }

    /**
     * post order print method, looks left and right then prints out
     */

    public void postOrder(Word node)
    {
        if(node != null)
        {
            if(node.getLeft() != null)
                postOrder(node.getLeft());

            if(node.getRight() != null)
                postOrder(node.getRight());

            System.out.println("english is - " + node.getEnglish());
            System.out.println(" German is  - " + node.getGerman());
            System.out.println(" ");
        }
    }

    /**
     * a method used to find if a node is a parent node. 
     * Method is used in the delete method
     */

    public Word findParent(String english)
    {
        Word previous = null;
        Word current = root;

        while( current != null)
        {

            int searchID = current.getEnglish().compareTo(english);
            if (searchID < 0)
            {
                previous = current;
                current = current.getLeft();
            }
            else if (searchID > 0)
            {   
                previous = current;
                current = current.getRight();
            }
            else
            {
                return previous;

            }

        }
        return null;
    }

    public void deleteNode(String english)
    {
        //if delete = null then it's not in the tree, return false in the future. 
        Word delete = search(english);

        // parent of the current
        Word previous = null;

        // parent of the delete node
        Word parent = findParent(delete.getEnglish());

        // current is the node that we want to replace the delete node
        Word current = delete.getRight();

        // if theres no right hand tree, use the first left instead.
        if(current == null)
        {
            current = delete.getLeft();

        }
        else
        {
            // while there is still a left, go left. 
            //The goal is to get to left most node in the right sub tree.
            while(current.getLeft() != null)
            {
                previous = current;
                current = current.getLeft();

            }
        }

        // double checking the current has a parent and if it does run the following to get the children

        if(previous != null)
        {

            // setting the currents children to be caught by previous
            if(current.getRight() != null)
            {
                previous.setLeft(current.getRight()); 
            }
            else
            {
                previous.setLeft(null);
            }

        }

        //deleting one of the parents children, understand which side it is and shift the whole tree 
        //so we don't lose it.

        if(parent != null)
        {

            // moving the current to the deleted position

            if(parent.getRight() == delete)
            {
                parent.setRight(current); 
            }
            else
            {
                parent.setLeft(current);
            }
        }
        else
        {
            // otherwise we know the id we want to delete is the root.
            if(current != root.getLeft())
                current.setLeft(root.getLeft());

            if(current != root.getRight())
                current.setRight(root.getRight());
            root = current;
        }
        //catching the deletes children in to the current

        //make sure not to loop infinitely by pointing at the delete.

        if(current != delete.getLeft())
            current.setLeft(delete.getLeft());

        if(current != delete.getRight())
            current.setRight(delete.getRight());

    }

    public void load()
    {

    }

    public void save(String name)
    {    
        name += ".txt";
        FileOutputStream outputStream = null;
        PrintWriter printWriter = null;
        try
        {
            outputStream = new FileOutputStream(name);
            printWriter = new PrintWriter(outputStream);    

            getPreOrder(root);

            printWriter.println(preorderEnglish);
            printWriter.println(preorderGerman);
            printWriter.close(); 
        }    

        catch (IOException e)
        {
            System.out.println("Sorry, there has been a problem opening or writing to the file");
        }

        System.out.println("You are no longer writing to a file.");          
    }

    /**
     * search method to find the student id of a student
     */

    public Word search(String english)
    {

        Word current = root;

        while( current != null)
        {

            int searchID = current.getEnglish().compareTo(english);
            if (searchID < 0)
                current = current.getLeft();
            else if (searchID > 0)
                current = current.getRight();
            else
            {
                return current;

            }

        }

        return null;
    }

    /**
     * Refactored version of Reading a file
     */

    private static BufferedReader openFileToRead(String read)
    {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        String nextLine = "";

        try
        {
            fileReader = new FileReader(read);
            bufferedReader = new BufferedReader(fileReader);          

        }
        catch (IOException e)
        {
            System.out.println("Sorry, an error occurred..");
        }

        return bufferedReader;
    }

    public void readInTranslation()
    {

        BufferedReader bufferedReader = openFileToRead("one.txt"); 
        // BufferedReader bufferedReader = openFileToRead("GermanToEnglishTranslation.txt"); 

        String english;
        String german;

        String input = "";
        String readLine = "";
        try
        {

            readLine = bufferedReader.readLine();
            while (readLine != null)
            {

                String[] list;
                list = readLine.split(" ");
                english = list[0];
                german = list[1];

                add(english,german);

                readLine = bufferedReader.readLine();

                System.out.println(english + "," + german);
            }
            System.out.println("Upload complete");
            Genio.getString();
        }
        catch (IOException e)
        {
            System.out.println("An error occurred when attempting to close the file");
        }
    }
    

    public void compareWord()
    {

    }

    public void calculateTimeTaken()
    {

    }
}